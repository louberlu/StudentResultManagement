#!/usr/bin/env python
# encoding: utf-8
# Généré par Mocodo 1.6.1 le Wed, 13 May 2015 07:35:27

import time, codecs

try:
	import json
except ImportError:
	import simplejson as json

geo = json.loads(open("mcd_projetStage2015-part2-geo.json").read())
(width,height) = geo.pop("size")
for (name,l) in geo.iteritems(): globals()[name] = dict(l)
cardMaxWidth = 21
cardMaxHeight = 14
cardMargin = 5
arrowWidth = 12
arrowHalfHeight = 6
arrowAxis = 8

def cardPos(ex,ey,ew,eh,ax,ay,k):
	if ax!=ex and abs(float(ay-ey)/(ax-ex)) < float(eh)/ew:
		(x0,x1) = (ex+cmp(ax,ex)*(ew+cardMargin), ex+cmp(ax,ex)*(ew+cardMargin+cardMaxWidth))
		(y0,y1) = sorted([ey+(x0-ex)*(ay-ey)/(ax-ex), ey+(x1-ex)*(ay-ey)/(ax-ex)])
		return (min(x0,x1),(y0+y1-cardMaxHeight+k*abs(y1-y0+cardMaxHeight))/2+cmp(k,0)*cardMargin)
	else:
		(y0,y1) = (ey+cmp(ay,ey)*(eh+cardMargin), ey+cmp(ay,ey)*(eh+cardMargin+cardMaxHeight))
		(x0,x1) = sorted([ex+(y0-ey)*(ax-ex)/(ay-ey), ex+(y1-ey)*(ax-ex)/(ay-ey)])
		return ((x0+x1-cardMaxWidth+k*abs(x1-x0+cardMaxWidth))/2+cmp(k,0)*cardMargin,min(y0,y1))

def lineArrow(x0,y0,x1,y1,t):
	(x,y) = (t*x0+(1-t)*x1,t*y0+(1-t)*y1)
	return arrow(x,y,x1-x0,y0-y1)
	
def curveArrow(x0,y0,x1,y1,x2,y2,x3,y3,t):
	(cx,cy) = (3*(x1-x0),3*(y1-y0))
	(bx,by) = (3*(x2-x1)-cx,3*(y2-y1)-cy)
	(ax,ay) = (x3-x0-cx-bx,y3-y0-cy-by)
	t = 1-t
	bezier  = lambda t: (ax*t*t*t + bx*t*t + cx*t + x0, ay*t*t*t + by*t*t + cy*t + y0)
	(x,y) = bezier(t)
	u = 1.0
	while t < u:
		m = (u+t)/2.0
		(xc,yc) = bezier(m)
		d = ((x-xc)**2+(y-yc)**2)**0.5
		if abs(d-arrowAxis) < 0.01:
			break
		if d > arrowAxis:
			u = m
		else:
			t = m
	return arrow(x,y,xc-x,y-yc)

def upperRoundRect(x,y,w,h,r):
	return " ".join([unicode(x) for x in ["M",x+w-r,y,"a",r,r,90,0,1,r,r,"V",y+h,"h",-w,"V",y+r,"a",r,r,90,0,1,r,-r]])

def lowerRoundRect(x,y,w,h,r):
	return " ".join([unicode(x) for x in ["M",x+w,y,"v",h-r,"a",r,r,90,0,1,-r,r,"H",x+r,"a",r,r,90,0,1,-r,-r,"V",y,"H",w]])

def arrow(x,y,a,b):
	c = (a*a+b*b)**0.5
	(cos,sin) = (a/c,b/c)
	return " ".join([unicode(x) for x in [
		"M",x,y,
		"L",x+arrowWidth*cos-arrowHalfHeight*sin,y-arrowHalfHeight*cos-arrowWidth*sin,
		"L",x+arrowAxis*cos,y-arrowAxis*sin,
		"L",x+arrowWidth*cos+arrowHalfHeight*sin,y+arrowHalfHeight*cos-arrowWidth*sin,
		"Z"
	]])

def safePrint(s):
	try:
		print s
	except UnicodeEncodeError:
		print s.encode("utf8")


lines = '<?xml version="1.0" standalone="no"?>\n<!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN"\n"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd">'
lines += '\n\n<svg width="%s" height="%s" viewBox="0 0 %s %s"\nxmlns="http://www.w3.org/2000/svg"\nxmlns:link="http://www.w3.org/1999/xlink">' % (width,height,width,height)
lines += u'\n\n<desc>Généré par Mocodo 1.6.1 le %s</desc>' % time.strftime("%a, %d %b %Y %H:%M:%S", time.localtime())
lines += '\n\n<rect x="0" y="0" width="%s" height="%s" fill="%s" stroke="none" stroke-width="0"/>' % (width,height,colors['backgroundColor'] if colors['backgroundColor'] else "none")

lines += u"""\n\n<!-- Association contient -->"""
(x,y) = (cx[u"contient"],cy[u"contient"])
(ex,ey) = (cx[u"Semestres"],cy[u"Semestres"])
lines += u"""\n<line x1="%(x0)s" y1="%(y0)s" x2="%(x1)s" y2="%(y1)s" stroke="%(strokeColor)s" stroke-width="2"/>""" % {'x0': ex, 'y0': ey, 'x1': x, 'y1': y, 'strokeColor': colors['legStrokeColor']}
(tx,ty) = cardPos(ex,11.9+ey,37,24,x,11.9+y,k[u"contient,Semestres"])
lines += u"""\n<text x="%(tx)s" y="%(ty)s" fill="%(textColor)s" font-family="Verdana" font-size="12">1,1</text>""" % {'tx': tx, 'ty': ty, 'textColor': colors['cardTextColor']}
path = lineArrow(ex,ey,x,y,t[u"contient,Semestres"])
lines += u"""\n<path d="%(path)s" fill="%(strokeColor)s" stroke-width="0"/>""" % {'path': path, 'strokeColor': colors['legStrokeColor']}
(ex,ey) = (cx[u"Annees"],cy[u"Annees"])
lines += u"""\n<line x1="%(x0)s" y1="%(y0)s" x2="%(x1)s" y2="%(y1)s" stroke="%(strokeColor)s" stroke-width="2"/>""" % {'x0': ex, 'y0': ey, 'x1': x, 'y1': y, 'strokeColor': colors['legStrokeColor']}
(tx,ty) = cardPos(ex,11.9+ey,38,40,x,11.9+y,k[u"contient,Annees"])
lines += u"""\n<text x="%(tx)s" y="%(ty)s" fill="%(textColor)s" font-family="Verdana" font-size="12">1,N</text>""" % {'tx': tx, 'ty': ty, 'textColor': colors['cardTextColor']}
lines += u"""\n<g id="association-contient">""" % {}
path = upperRoundRect(-32+x,-24+y,64,24,14)
lines += u"""\n	<path d="%(path)s" fill="%(color)s" stroke="%(strokeColor)s" stroke-width="0"/>""" % {'path': path, 'color': colors['associationCartoucheColor'], 'strokeColor': colors['associationCartoucheColor']}
path = lowerRoundRect(-32+x,0+y,64,24,14)
lines += u"""\n	<path d="%(path)s" fill="%(color)s" stroke="%(strokeColor)s" stroke-width="0"/>""" % {'path': path, 'color': colors['associationColor'], 'strokeColor': colors['associationColor']}
lines += u"""\n	<rect x="%(x)s" y="%(y)s" width="64" height="48" fill="%(color)s" rx="14" stroke="%(strokeColor)s" stroke-width="2"/>""" % {'x': -32+x, 'y': -24+y, 'color': colors['transparentColor'], 'strokeColor': colors['associationStrokeColor']}
lines += u"""\n	<line x1="%(x0)s" y1="%(y0)s" x2="%(x1)s" y2="%(y1)s" stroke="%(strokeColor)s" stroke-width="1"/>""" % {'x0': -32+x, 'y0': 0+y, 'x1': 32+x, 'y1': 0+y, 'strokeColor': colors['associationStrokeColor']}
lines += u"""\n	<text x="%(x)s" y="%(y)s" fill="%(textColor)s" font-family="Verdana" font-size="12">contient</text>""" % {'x': -25+x, 'y': -7.1+y, 'textColor': colors['associationCartoucheTextColor']}
lines += u"""\n</g>""" % {}

lines += u"""\n\n<!-- Association associées_aux -->"""
(x,y) = (cx[u"associées_aux"],cy[u"associées_aux"])
(ex,ey) = (cx[u"UEs"],cy[u"UEs"])
lines += u"""\n<line x1="%(x0)s" y1="%(y0)s" x2="%(x1)s" y2="%(y1)s" stroke="%(strokeColor)s" stroke-width="2"/>""" % {'x0': ex, 'y0': ey, 'x1': x, 'y1': y, 'strokeColor': colors['legStrokeColor']}
(tx,ty) = cardPos(ex,11.9+ey,37,64,x,11.9+y,k[u"associées_aux,UEs"])
lines += u"""\n<text x="%(tx)s" y="%(ty)s" fill="%(textColor)s" font-family="Verdana" font-size="12">1,1</text>""" % {'tx': tx, 'ty': ty, 'textColor': colors['cardTextColor']}
(ex,ey) = (cx[u"Semestres"],cy[u"Semestres"])
lines += u"""\n<line x1="%(x0)s" y1="%(y0)s" x2="%(x1)s" y2="%(y1)s" stroke="%(strokeColor)s" stroke-width="2"/>""" % {'x0': ex, 'y0': ey, 'x1': x, 'y1': y, 'strokeColor': colors['legStrokeColor']}
(tx,ty) = cardPos(ex,11.9+ey,37,24,x,11.9+y,k[u"associées_aux,Semestres"])
lines += u"""\n<text x="%(tx)s" y="%(ty)s" fill="%(textColor)s" font-family="Verdana" font-size="12">1,N</text>""" % {'tx': tx, 'ty': ty, 'textColor': colors['cardTextColor']}
lines += u"""\n<g id="association-associées_aux">""" % {}
path = upperRoundRect(-51+x,-24+y,102,24,14)
lines += u"""\n	<path d="%(path)s" fill="%(color)s" stroke="%(strokeColor)s" stroke-width="0"/>""" % {'path': path, 'color': colors['associationCartoucheColor'], 'strokeColor': colors['associationCartoucheColor']}
path = lowerRoundRect(-51+x,0+y,102,24,14)
lines += u"""\n	<path d="%(path)s" fill="%(color)s" stroke="%(strokeColor)s" stroke-width="0"/>""" % {'path': path, 'color': colors['associationColor'], 'strokeColor': colors['associationColor']}
lines += u"""\n	<rect x="%(x)s" y="%(y)s" width="102" height="48" fill="%(color)s" rx="14" stroke="%(strokeColor)s" stroke-width="2"/>""" % {'x': -51+x, 'y': -24+y, 'color': colors['transparentColor'], 'strokeColor': colors['associationStrokeColor']}
lines += u"""\n	<line x1="%(x0)s" y1="%(y0)s" x2="%(x1)s" y2="%(y1)s" stroke="%(strokeColor)s" stroke-width="1"/>""" % {'x0': -51+x, 'y0': 0+y, 'x1': 51+x, 'y1': 0+y, 'strokeColor': colors['associationStrokeColor']}
lines += u"""\n	<text x="%(x)s" y="%(y)s" fill="%(textColor)s" font-family="Verdana" font-size="12">associées_aux</text>""" % {'x': -44+x, 'y': -7.1+y, 'textColor': colors['associationCartoucheTextColor']}
lines += u"""\n</g>""" % {}

lines += u"""\n\n<!-- Entity Annees -->"""
(x,y) = (cx[u"Annees"],cy[u"Annees"])
lines += u"""\n<g id="entity-Annees">""" % {}
lines += u"""\n	<g id="frame-Annees">""" % {}
lines += u"""\n		<rect x="%(x)s" y="%(y)s" width="76" height="24" fill="%(color)s" stroke="%(strokeColor)s" stroke-width="0"/>""" % {'x': -38+x, 'y': -40+y, 'color': colors['entityCartoucheColor'], 'strokeColor': colors['entityCartoucheColor']}
lines += u"""\n		<rect x="%(x)s" y="%(y)s" width="76" height="56" fill="%(color)s" stroke="%(strokeColor)s" stroke-width="0"/>""" % {'x': -38+x, 'y': -16+y, 'color': colors['entityColor'], 'strokeColor': colors['entityColor']}
lines += u"""\n		<rect x="%(x)s" y="%(y)s" width="76" height="80" fill="%(color)s" stroke="%(strokeColor)s" stroke-width="2"/>""" % {'x': -38+x, 'y': -40+y, 'color': colors['transparentColor'], 'strokeColor': colors['entityStrokeColor']}
lines += u"""\n		<line x1="%(x0)s" y1="%(y0)s" x2="%(x1)s" y2="%(y1)s" stroke="%(strokeColor)s" stroke-width="1"/>""" % {'x0': -38+x, 'y0': -16+y, 'x1': 38+x, 'y1': -16+y, 'strokeColor': colors['entityStrokeColor']}
lines += u"""\n	</g>""" % {}
lines += u"""\n	<text x="%(x)s" y="%(y)s" fill="%(textColor)s" font-family="Verdana" font-size="12">Annees</text>""" % {'x': -22+x, 'y': -23.1+y, 'textColor': colors['entityCartoucheTextColor']}
lines += u"""\n	<text x="%(x)s" y="%(y)s" fill="%(textColor)s" font-family="Verdana" font-size="12">id</text>""" % {'x': -33+x, 'y': 0.9+y, 'textColor': colors['entityAttributeTextColor']}
lines += u"""\n	<line x1="%(x0)s" y1="%(y0)s" x2="%(x1)s" y2="%(y1)s" stroke="%(strokeColor)s" stroke-width="1"/>""" % {'x0': -33+x, 'y0': 3.0+y, 'x1': -22+x, 'y1': 3.0+y, 'strokeColor': colors['entityAttributeTextColor']}
lines += u"""\n	<text x="%(x)s" y="%(y)s" fill="%(textColor)s" font-family="Verdana" font-size="12">diplome</text>""" % {'x': -33+x, 'y': 16.9+y, 'textColor': colors['entityAttributeTextColor']}
lines += u"""\n	<text x="%(x)s" y="%(y)s" fill="%(textColor)s" font-family="Verdana" font-size="12">description</text>""" % {'x': -33+x, 'y': 32.9+y, 'textColor': colors['entityAttributeTextColor']}
lines += u"""\n</g>""" % {}

lines += u"""\n\n<!-- Entity Semestres -->"""
(x,y) = (cx[u"Semestres"],cy[u"Semestres"])
lines += u"""\n<g id="entity-Semestres">""" % {}
lines += u"""\n	<g id="frame-Semestres">""" % {}
lines += u"""\n		<rect x="%(x)s" y="%(y)s" width="74" height="24" fill="%(color)s" stroke="%(strokeColor)s" stroke-width="0"/>""" % {'x': -37+x, 'y': -24+y, 'color': colors['entityCartoucheColor'], 'strokeColor': colors['entityCartoucheColor']}
lines += u"""\n		<rect x="%(x)s" y="%(y)s" width="74" height="24" fill="%(color)s" stroke="%(strokeColor)s" stroke-width="0"/>""" % {'x': -37+x, 'y': 0+y, 'color': colors['entityColor'], 'strokeColor': colors['entityColor']}
lines += u"""\n		<rect x="%(x)s" y="%(y)s" width="74" height="48" fill="%(color)s" stroke="%(strokeColor)s" stroke-width="2"/>""" % {'x': -37+x, 'y': -24+y, 'color': colors['transparentColor'], 'strokeColor': colors['entityStrokeColor']}
lines += u"""\n		<line x1="%(x0)s" y1="%(y0)s" x2="%(x1)s" y2="%(y1)s" stroke="%(strokeColor)s" stroke-width="1"/>""" % {'x0': -37+x, 'y0': 0+y, 'x1': 37+x, 'y1': 0+y, 'strokeColor': colors['entityStrokeColor']}
lines += u"""\n	</g>""" % {}
lines += u"""\n	<text x="%(x)s" y="%(y)s" fill="%(textColor)s" font-family="Verdana" font-size="12">Semestres</text>""" % {'x': -32+x, 'y': -7.1+y, 'textColor': colors['entityCartoucheTextColor']}
lines += u"""\n	<text x="%(x)s" y="%(y)s" fill="%(textColor)s" font-family="Verdana" font-size="12">numSem</text>""" % {'x': -32+x, 'y': 16.9+y, 'textColor': colors['entityAttributeTextColor']}
lines += u"""\n	<line x1="%(x0)s" y1="%(y)s" x2="%(x1)s" y2="%(y)s" style="fill:none;stroke:%(strokeColor)s;stroke-width:1;stroke-dasharray:4;"/>""" % {'x0': -32+x, 'y': 19.0+y, 'x1': 22+x, 'y': 19.0+y, 'strokeColor': colors['entityAttributeTextColor']}
lines += u"""\n</g>""" % {}

lines += u"""\n\n<!-- Entity UEs -->"""
(x,y) = (cx[u"UEs"],cy[u"UEs"])
lines += u"""\n<g id="entity-UEs">""" % {}
lines += u"""\n	<g id="frame-UEs">""" % {}
lines += u"""\n		<rect x="%(x)s" y="%(y)s" width="74" height="24" fill="%(color)s" stroke="%(strokeColor)s" stroke-width="0"/>""" % {'x': -37+x, 'y': -64+y, 'color': colors['entityCartoucheColor'], 'strokeColor': colors['entityCartoucheColor']}
lines += u"""\n		<rect x="%(x)s" y="%(y)s" width="74" height="104" fill="%(color)s" stroke="%(strokeColor)s" stroke-width="0"/>""" % {'x': -37+x, 'y': -40+y, 'color': colors['entityColor'], 'strokeColor': colors['entityColor']}
lines += u"""\n		<rect x="%(x)s" y="%(y)s" width="74" height="128" fill="%(color)s" stroke="%(strokeColor)s" stroke-width="2"/>""" % {'x': -37+x, 'y': -64+y, 'color': colors['transparentColor'], 'strokeColor': colors['entityStrokeColor']}
lines += u"""\n		<line x1="%(x0)s" y1="%(y0)s" x2="%(x1)s" y2="%(y1)s" stroke="%(strokeColor)s" stroke-width="1"/>""" % {'x0': -37+x, 'y0': -40+y, 'x1': 37+x, 'y1': -40+y, 'strokeColor': colors['entityStrokeColor']}
lines += u"""\n	</g>""" % {}
lines += u"""\n	<text x="%(x)s" y="%(y)s" fill="%(textColor)s" font-family="Verdana" font-size="12">UEs</text>""" % {'x': -12+x, 'y': -47.1+y, 'textColor': colors['entityCartoucheTextColor']}
lines += u"""\n	<text x="%(x)s" y="%(y)s" fill="%(textColor)s" font-family="Verdana" font-size="12">id</text>""" % {'x': -32+x, 'y': -23.1+y, 'textColor': colors['entityAttributeTextColor']}
lines += u"""\n	<line x1="%(x0)s" y1="%(y0)s" x2="%(x1)s" y2="%(y1)s" stroke="%(strokeColor)s" stroke-width="1"/>""" % {'x0': -32+x, 'y0': -21.0+y, 'x1': -21+x, 'y1': -21.0+y, 'strokeColor': colors['entityAttributeTextColor']}
lines += u"""\n	<text x="%(x)s" y="%(y)s" fill="%(textColor)s" font-family="Verdana" font-size="12">name</text>""" % {'x': -32+x, 'y': -7.1+y, 'textColor': colors['entityAttributeTextColor']}
lines += u"""\n	<text x="%(x)s" y="%(y)s" fill="%(textColor)s" font-family="Verdana" font-size="12">sup1</text>""" % {'x': -32+x, 'y': 8.9+y, 'textColor': colors['entityAttributeTextColor']}
lines += u"""\n	<text x="%(x)s" y="%(y)s" fill="%(textColor)s" font-family="Verdana" font-size="12">sup2</text>""" % {'x': -32+x, 'y': 24.9+y, 'textColor': colors['entityAttributeTextColor']}
lines += u"""\n	<text x="%(x)s" y="%(y)s" fill="%(textColor)s" font-family="Verdana" font-size="12">obligatoire</text>""" % {'x': -32+x, 'y': 40.9+y, 'textColor': colors['entityAttributeTextColor']}
lines += u"""\n	<text x="%(x)s" y="%(y)s" fill="%(textColor)s" font-family="Verdana" font-size="12">coefUE</text>""" % {'x': -32+x, 'y': 56.9+y, 'textColor': colors['entityAttributeTextColor']}
lines += u"""\n</g>""" % {}
lines += u'\n</svg>'

import codecs
codecs.open("mcd_projetStage2015-part2.svg","w","utf8").write(lines)
safePrint(u'Fichier de sortie "mcd_projetStage2015-part2.svg" généré avec succès.')