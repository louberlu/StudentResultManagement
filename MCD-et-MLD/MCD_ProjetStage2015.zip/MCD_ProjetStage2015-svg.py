#!/usr/bin/env python
# encoding: utf-8
# Généré par Mocodo 1.6.1 le Wed, 13 May 2015 02:21:21

import time, codecs

try:
	import json
except ImportError:
	import simplejson as json

geo = json.loads(open("MCD_ProjetStage2015-geo.json").read())
(width,height) = geo.pop("size")
for (name,l) in geo.iteritems(): globals()[name] = dict(l)
cardMaxWidth = 21
cardMaxHeight = 14
cardMargin = 5
arrowWidth = 12
arrowHalfHeight = 6
arrowAxis = 8

def cardPos(ex,ey,ew,eh,ax,ay,k):
	if ax!=ex and abs(float(ay-ey)/(ax-ex)) < float(eh)/ew:
		(x0,x1) = (ex+cmp(ax,ex)*(ew+cardMargin), ex+cmp(ax,ex)*(ew+cardMargin+cardMaxWidth))
		(y0,y1) = sorted([ey+(x0-ex)*(ay-ey)/(ax-ex), ey+(x1-ex)*(ay-ey)/(ax-ex)])
		return (min(x0,x1),(y0+y1-cardMaxHeight+k*abs(y1-y0+cardMaxHeight))/2+cmp(k,0)*cardMargin)
	else:
		(y0,y1) = (ey+cmp(ay,ey)*(eh+cardMargin), ey+cmp(ay,ey)*(eh+cardMargin+cardMaxHeight))
		(x0,x1) = sorted([ex+(y0-ey)*(ax-ex)/(ay-ey), ex+(y1-ey)*(ax-ex)/(ay-ey)])
		return ((x0+x1-cardMaxWidth+k*abs(x1-x0+cardMaxWidth))/2+cmp(k,0)*cardMargin,min(y0,y1))

def lineArrow(x0,y0,x1,y1,t):
	(x,y) = (t*x0+(1-t)*x1,t*y0+(1-t)*y1)
	return arrow(x,y,x1-x0,y0-y1)
	
def curveArrow(x0,y0,x1,y1,x2,y2,x3,y3,t):
	(cx,cy) = (3*(x1-x0),3*(y1-y0))
	(bx,by) = (3*(x2-x1)-cx,3*(y2-y1)-cy)
	(ax,ay) = (x3-x0-cx-bx,y3-y0-cy-by)
	t = 1-t
	bezier  = lambda t: (ax*t*t*t + bx*t*t + cx*t + x0, ay*t*t*t + by*t*t + cy*t + y0)
	(x,y) = bezier(t)
	u = 1.0
	while t < u:
		m = (u+t)/2.0
		(xc,yc) = bezier(m)
		d = ((x-xc)**2+(y-yc)**2)**0.5
		if abs(d-arrowAxis) < 0.01:
			break
		if d > arrowAxis:
			u = m
		else:
			t = m
	return arrow(x,y,xc-x,y-yc)

def upperRoundRect(x,y,w,h,r):
	return " ".join([unicode(x) for x in ["M",x+w-r,y,"a",r,r,90,0,1,r,r,"V",y+h,"h",-w,"V",y+r,"a",r,r,90,0,1,r,-r]])

def lowerRoundRect(x,y,w,h,r):
	return " ".join([unicode(x) for x in ["M",x+w,y,"v",h-r,"a",r,r,90,0,1,-r,r,"H",x+r,"a",r,r,90,0,1,-r,-r,"V",y,"H",w]])

def arrow(x,y,a,b):
	c = (a*a+b*b)**0.5
	(cos,sin) = (a/c,b/c)
	return " ".join([unicode(x) for x in [
		"M",x,y,
		"L",x+arrowWidth*cos-arrowHalfHeight*sin,y-arrowHalfHeight*cos-arrowWidth*sin,
		"L",x+arrowAxis*cos,y-arrowAxis*sin,
		"L",x+arrowWidth*cos+arrowHalfHeight*sin,y+arrowHalfHeight*cos-arrowWidth*sin,
		"Z"
	]])

def safePrint(s):
	try:
		print s
	except UnicodeEncodeError:
		print s.encode("utf8")


lines = '<?xml version="1.0" standalone="no"?>\n<!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN"\n"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd">'
lines += '\n\n<svg width="%s" height="%s" viewBox="0 0 %s %s"\nxmlns="http://www.w3.org/2000/svg"\nxmlns:link="http://www.w3.org/1999/xlink">' % (width,height,width,height)
lines += u'\n\n<desc>Généré par Mocodo 1.6.1 le %s</desc>' % time.strftime("%a, %d %b %Y %H:%M:%S", time.localtime())
lines += '\n\n<rect x="0" y="0" width="%s" height="%s" fill="%s" stroke="none" stroke-width="0"/>' % (width,height,colors['backgroundColor'] if colors['backgroundColor'] else "none")

lines += u"""\n\n<!-- Association contient -->"""
(x,y) = (cx[u"contient"],cy[u"contient"])
(ex,ey) = (cx[u"Semestres"],cy[u"Semestres"])
lines += u"""\n<line x1="%(x0)s" y1="%(y0)s" x2="%(x1)s" y2="%(y1)s" stroke="%(strokeColor)s" stroke-width="2"/>""" % {'x0': ex, 'y0': ey, 'x1': x, 'y1': y, 'strokeColor': colors['legStrokeColor']}
(tx,ty) = cardPos(ex,11.9+ey,37,24,x,11.9+y,k[u"contient,Semestres"])
lines += u"""\n<text x="%(tx)s" y="%(ty)s" fill="%(textColor)s" font-family="Verdana" font-size="12">1,1</text>""" % {'tx': tx, 'ty': ty, 'textColor': colors['cardTextColor']}
path = lineArrow(ex,ey,x,y,t[u"contient,Semestres"])
lines += u"""\n<path d="%(path)s" fill="%(strokeColor)s" stroke-width="0"/>""" % {'path': path, 'strokeColor': colors['legStrokeColor']}
(ex,ey) = (cx[u"Annees"],cy[u"Annees"])
lines += u"""\n<line x1="%(x0)s" y1="%(y0)s" x2="%(x1)s" y2="%(y1)s" stroke="%(strokeColor)s" stroke-width="2"/>""" % {'x0': ex, 'y0': ey, 'x1': x, 'y1': y, 'strokeColor': colors['legStrokeColor']}
(tx,ty) = cardPos(ex,11.9+ey,38,40,x,11.9+y,k[u"contient,Annees"])
lines += u"""\n<text x="%(tx)s" y="%(ty)s" fill="%(textColor)s" font-family="Verdana" font-size="12">1,N</text>""" % {'tx': tx, 'ty': ty, 'textColor': colors['cardTextColor']}
lines += u"""\n<g id="association-contient">""" % {}
path = upperRoundRect(-32+x,-24+y,64,24,14)
lines += u"""\n	<path d="%(path)s" fill="%(color)s" stroke="%(strokeColor)s" stroke-width="0"/>""" % {'path': path, 'color': colors['associationCartoucheColor'], 'strokeColor': colors['associationCartoucheColor']}
path = lowerRoundRect(-32+x,0+y,64,24,14)
lines += u"""\n	<path d="%(path)s" fill="%(color)s" stroke="%(strokeColor)s" stroke-width="0"/>""" % {'path': path, 'color': colors['associationColor'], 'strokeColor': colors['associationColor']}
lines += u"""\n	<rect x="%(x)s" y="%(y)s" width="64" height="48" fill="%(color)s" rx="14" stroke="%(strokeColor)s" stroke-width="2"/>""" % {'x': -32+x, 'y': -24+y, 'color': colors['transparentColor'], 'strokeColor': colors['associationStrokeColor']}
lines += u"""\n	<line x1="%(x0)s" y1="%(y0)s" x2="%(x1)s" y2="%(y1)s" stroke="%(strokeColor)s" stroke-width="1"/>""" % {'x0': -32+x, 'y0': 0+y, 'x1': 32+x, 'y1': 0+y, 'strokeColor': colors['associationStrokeColor']}
lines += u"""\n	<text x="%(x)s" y="%(y)s" fill="%(textColor)s" font-family="Verdana" font-size="12">contient</text>""" % {'x': -25+x, 'y': -7.1+y, 'textColor': colors['associationCartoucheTextColor']}
lines += u"""\n</g>""" % {}

lines += u"""\n\n<!-- Association étudient -->"""
(x,y) = (cx[u"étudient"],cy[u"étudient"])
(ex,ey) = (cx[u"Etudiants"],cy[u"Etudiants"])
lines += u"""\n<line x1="%(x0)s" y1="%(y0)s" x2="%(x1)s" y2="%(y1)s" stroke="%(strokeColor)s" stroke-width="2"/>""" % {'x0': ex, 'y0': ey, 'x1': x, 'y1': y, 'strokeColor': colors['legStrokeColor']}
(tx,ty) = cardPos(ex,11.9+ey,33,24,x,11.9+y,k[u"étudient,Etudiants"])
lines += u"""\n<text x="%(tx)s" y="%(ty)s" fill="%(textColor)s" font-family="Verdana" font-size="12">0,N</text>""" % {'tx': tx, 'ty': ty, 'textColor': colors['cardTextColor']}
(ex,ey) = (cx[u"Annees"],cy[u"Annees"])
lines += u"""\n<line x1="%(x0)s" y1="%(y0)s" x2="%(x1)s" y2="%(y1)s" stroke="%(strokeColor)s" stroke-width="2"/>""" % {'x0': ex, 'y0': ey, 'x1': x, 'y1': y, 'strokeColor': colors['legStrokeColor']}
(tx,ty) = cardPos(ex,11.9+ey,38,40,x,11.9+y,k[u"étudient,Annees"])
lines += u"""\n<text x="%(tx)s" y="%(ty)s" fill="%(textColor)s" font-family="Verdana" font-size="12">0,N</text>""" % {'tx': tx, 'ty': ty, 'textColor': colors['cardTextColor']}
lines += u"""\n<g id="association-étudient">""" % {}
path = upperRoundRect(-47+x,-40+y,94,24,14)
lines += u"""\n	<path d="%(path)s" fill="%(color)s" stroke="%(strokeColor)s" stroke-width="0"/>""" % {'path': path, 'color': colors['associationCartoucheColor'], 'strokeColor': colors['associationCartoucheColor']}
path = lowerRoundRect(-47+x,-16+y,94,56,14)
lines += u"""\n	<path d="%(path)s" fill="%(color)s" stroke="%(strokeColor)s" stroke-width="0"/>""" % {'path': path, 'color': colors['associationColor'], 'strokeColor': colors['associationColor']}
lines += u"""\n	<rect x="%(x)s" y="%(y)s" width="94" height="80" fill="%(color)s" rx="14" stroke="%(strokeColor)s" stroke-width="2"/>""" % {'x': -47+x, 'y': -40+y, 'color': colors['transparentColor'], 'strokeColor': colors['associationStrokeColor']}
lines += u"""\n	<line x1="%(x0)s" y1="%(y0)s" x2="%(x1)s" y2="%(y1)s" stroke="%(strokeColor)s" stroke-width="1"/>""" % {'x0': -47+x, 'y0': -16+y, 'x1': 47+x, 'y1': -16+y, 'strokeColor': colors['associationStrokeColor']}
lines += u"""\n	<text x="%(x)s" y="%(y)s" fill="%(textColor)s" font-family="Verdana" font-size="12">étudient</text>""" % {'x': -25+x, 'y': -23.1+y, 'textColor': colors['associationCartoucheTextColor']}
lines += u"""\n	<text x="%(x)s" y="%(y)s" fill="%(textColor)s" font-family="Verdana" font-size="12">moyAn</text>""" % {'x': -40+x, 'y': 0.9+y, 'textColor': colors['associationAttributeTextColor']}
lines += u"""\n	<text x="%(x)s" y="%(y)s" fill="%(textColor)s" font-family="Verdana" font-size="12">admis</text>""" % {'x': -40+x, 'y': 16.9+y, 'textColor': colors['associationAttributeTextColor']}
lines += u"""\n	<text x="%(x)s" y="%(y)s" fill="%(textColor)s" font-family="Verdana" font-size="12">compensable</text>""" % {'x': -40+x, 'y': 32.9+y, 'textColor': colors['associationAttributeTextColor']}
lines += u"""\n</g>""" % {}

lines += u"""\n\n<!-- Association coef -->"""
(x,y) = (cx[u"coef"],cy[u"coef"])
(ex,ey) = (cx[u"UEs"],cy[u"UEs"])
lines += u"""\n<line x1="%(x0)s" y1="%(y0)s" x2="%(x1)s" y2="%(y1)s" stroke="%(strokeColor)s" stroke-width="2"/>""" % {'x0': ex, 'y0': ey, 'x1': x, 'y1': y, 'strokeColor': colors['legStrokeColor']}
(tx,ty) = cardPos(ex,11.9+ey,37,64,x,11.9+y,k[u"coef,UEs"])
lines += u"""\n<text x="%(tx)s" y="%(ty)s" fill="%(textColor)s" font-family="Verdana" font-size="12">0,N</text>""" % {'tx': tx, 'ty': ty, 'textColor': colors['cardTextColor']}
(ex,ey) = (cx[u"Types_Notes"],cy[u"Types_Notes"])
lines += u"""\n<line x1="%(x0)s" y1="%(y0)s" x2="%(x1)s" y2="%(y1)s" stroke="%(strokeColor)s" stroke-width="2"/>""" % {'x0': ex, 'y0': ey, 'x1': x, 'y1': y, 'strokeColor': colors['legStrokeColor']}
(tx,ty) = cardPos(ex,11.9+ey,44,40,x,11.9+y,k[u"coef,Types_Notes"])
lines += u"""\n<text x="%(tx)s" y="%(ty)s" fill="%(textColor)s" font-family="Verdana" font-size="12">0,N</text>""" % {'tx': tx, 'ty': ty, 'textColor': colors['cardTextColor']}
lines += u"""\n<g id="association-coef">""" % {}
path = upperRoundRect(-33+x,-32+y,66,24,14)
lines += u"""\n	<path d="%(path)s" fill="%(color)s" stroke="%(strokeColor)s" stroke-width="0"/>""" % {'path': path, 'color': colors['associationCartoucheColor'], 'strokeColor': colors['associationCartoucheColor']}
path = lowerRoundRect(-33+x,-8+y,66,40,14)
lines += u"""\n	<path d="%(path)s" fill="%(color)s" stroke="%(strokeColor)s" stroke-width="0"/>""" % {'path': path, 'color': colors['associationColor'], 'strokeColor': colors['associationColor']}
lines += u"""\n	<rect x="%(x)s" y="%(y)s" width="66" height="64" fill="%(color)s" rx="14" stroke="%(strokeColor)s" stroke-width="2"/>""" % {'x': -33+x, 'y': -32+y, 'color': colors['transparentColor'], 'strokeColor': colors['associationStrokeColor']}
lines += u"""\n	<line x1="%(x0)s" y1="%(y0)s" x2="%(x1)s" y2="%(y1)s" stroke="%(strokeColor)s" stroke-width="1"/>""" % {'x0': -33+x, 'y0': -8+y, 'x1': 33+x, 'y1': -8+y, 'strokeColor': colors['associationStrokeColor']}
lines += u"""\n	<text x="%(x)s" y="%(y)s" fill="%(textColor)s" font-family="Verdana" font-size="12">coef</text>""" % {'x': -13+x, 'y': -15.1+y, 'textColor': colors['associationCartoucheTextColor']}
lines += u"""\n	<text x="%(x)s" y="%(y)s" fill="%(textColor)s" font-family="Verdana" font-size="12">coefNo</text>""" % {'x': -26+x, 'y': 8.9+y, 'textColor': colors['associationAttributeTextColor']}
lines += u"""\n	<text x="%(x)s" y="%(y)s" fill="%(textColor)s" font-family="Verdana" font-size="12">sessoin1</text>""" % {'x': -26+x, 'y': 24.9+y, 'textColor': colors['associationAttributeTextColor']}
lines += u"""\n</g>""" % {}

lines += u"""\n\n<!-- Association enseignent -->"""
(x,y) = (cx[u"enseignent"],cy[u"enseignent"])
(ex,ey) = (cx[u"UEs"],cy[u"UEs"])
lines += u"""\n<line x1="%(x0)s" y1="%(y0)s" x2="%(x1)s" y2="%(y1)s" stroke="%(strokeColor)s" stroke-width="2"/>""" % {'x0': ex, 'y0': ey, 'x1': x, 'y1': y, 'strokeColor': colors['legStrokeColor']}
(tx,ty) = cardPos(ex,11.9+ey,37,64,x,11.9+y,k[u"enseignent,UEs"])
lines += u"""\n<text x="%(tx)s" y="%(ty)s" fill="%(textColor)s" font-family="Verdana" font-size="12">0,N</text>""" % {'tx': tx, 'ty': ty, 'textColor': colors['cardTextColor']}
(ex,ey) = (cx[u"Enseignants"],cy[u"Enseignants"])
lines += u"""\n<line x1="%(x0)s" y1="%(y0)s" x2="%(x1)s" y2="%(y1)s" stroke="%(strokeColor)s" stroke-width="2"/>""" % {'x0': ex, 'y0': ey, 'x1': x, 'y1': y, 'strokeColor': colors['legStrokeColor']}
(tx,ty) = cardPos(ex,11.9+ey,42,24,x,11.9+y,k[u"enseignent,Enseignants"])
lines += u"""\n<text x="%(tx)s" y="%(ty)s" fill="%(textColor)s" font-family="Verdana" font-size="12">0,N</text>""" % {'tx': tx, 'ty': ty, 'textColor': colors['cardTextColor']}
lines += u"""\n<g id="association-enseignent">""" % {}
path = upperRoundRect(-40+x,-24+y,80,24,14)
lines += u"""\n	<path d="%(path)s" fill="%(color)s" stroke="%(strokeColor)s" stroke-width="0"/>""" % {'path': path, 'color': colors['associationCartoucheColor'], 'strokeColor': colors['associationCartoucheColor']}
path = lowerRoundRect(-40+x,0+y,80,24,14)
lines += u"""\n	<path d="%(path)s" fill="%(color)s" stroke="%(strokeColor)s" stroke-width="0"/>""" % {'path': path, 'color': colors['associationColor'], 'strokeColor': colors['associationColor']}
lines += u"""\n	<rect x="%(x)s" y="%(y)s" width="80" height="48" fill="%(color)s" rx="14" stroke="%(strokeColor)s" stroke-width="2"/>""" % {'x': -40+x, 'y': -24+y, 'color': colors['transparentColor'], 'strokeColor': colors['associationStrokeColor']}
lines += u"""\n	<line x1="%(x0)s" y1="%(y0)s" x2="%(x1)s" y2="%(y1)s" stroke="%(strokeColor)s" stroke-width="1"/>""" % {'x0': -40+x, 'y0': 0+y, 'x1': 40+x, 'y1': 0+y, 'strokeColor': colors['associationStrokeColor']}
lines += u"""\n	<text x="%(x)s" y="%(y)s" fill="%(textColor)s" font-family="Verdana" font-size="12">enseignent</text>""" % {'x': -33+x, 'y': -7.1+y, 'textColor': colors['associationCartoucheTextColor']}
lines += u"""\n</g>""" % {}

lines += u"""\n\n<!-- Association inscrivent -->"""
(x,y) = (cx[u"inscrivent"],cy[u"inscrivent"])
(ex,ey) = (cx[u"UEs"],cy[u"UEs"])
lines += u"""\n<line x1="%(x0)s" y1="%(y0)s" x2="%(x1)s" y2="%(y1)s" stroke="%(strokeColor)s" stroke-width="2"/>""" % {'x0': ex, 'y0': ey, 'x1': x, 'y1': y, 'strokeColor': colors['legStrokeColor']}
(tx,ty) = cardPos(ex,11.9+ey,37,64,x,11.9+y,k[u"inscrivent,UEs"])
lines += u"""\n<text x="%(tx)s" y="%(ty)s" fill="%(textColor)s" font-family="Verdana" font-size="12">0,N</text>""" % {'tx': tx, 'ty': ty, 'textColor': colors['cardTextColor']}
(ex,ey) = (cx[u"Etudiants"],cy[u"Etudiants"])
lines += u"""\n<line x1="%(x0)s" y1="%(y0)s" x2="%(x1)s" y2="%(y1)s" stroke="%(strokeColor)s" stroke-width="2"/>""" % {'x0': ex, 'y0': ey, 'x1': x, 'y1': y, 'strokeColor': colors['legStrokeColor']}
(tx,ty) = cardPos(ex,11.9+ey,33,24,x,11.9+y,k[u"inscrivent,Etudiants"])
lines += u"""\n<text x="%(tx)s" y="%(ty)s" fill="%(textColor)s" font-family="Verdana" font-size="12">0,N</text>""" % {'tx': tx, 'ty': ty, 'textColor': colors['cardTextColor']}
lines += u"""\n<g id="association-inscrivent">""" % {}
path = upperRoundRect(-36+x,-24+y,72,24,14)
lines += u"""\n	<path d="%(path)s" fill="%(color)s" stroke="%(strokeColor)s" stroke-width="0"/>""" % {'path': path, 'color': colors['associationCartoucheColor'], 'strokeColor': colors['associationCartoucheColor']}
path = lowerRoundRect(-36+x,0+y,72,24,14)
lines += u"""\n	<path d="%(path)s" fill="%(color)s" stroke="%(strokeColor)s" stroke-width="0"/>""" % {'path': path, 'color': colors['associationColor'], 'strokeColor': colors['associationColor']}
lines += u"""\n	<rect x="%(x)s" y="%(y)s" width="72" height="48" fill="%(color)s" rx="14" stroke="%(strokeColor)s" stroke-width="2"/>""" % {'x': -36+x, 'y': -24+y, 'color': colors['transparentColor'], 'strokeColor': colors['associationStrokeColor']}
lines += u"""\n	<line x1="%(x0)s" y1="%(y0)s" x2="%(x1)s" y2="%(y1)s" stroke="%(strokeColor)s" stroke-width="1"/>""" % {'x0': -36+x, 'y0': 0+y, 'x1': 36+x, 'y1': 0+y, 'strokeColor': colors['associationStrokeColor']}
lines += u"""\n	<text x="%(x)s" y="%(y)s" fill="%(textColor)s" font-family="Verdana" font-size="12">inscrivent</text>""" % {'x': -29+x, 'y': -7.1+y, 'textColor': colors['associationCartoucheTextColor']}
lines += u"""\n	<text x="%(x)s" y="%(y)s" fill="%(textColor)s" font-family="Verdana" font-size="12">dispense</text>""" % {'x': -29+x, 'y': 16.9+y, 'textColor': colors['associationAttributeTextColor']}
lines += u"""\n</g>""" % {}

lines += u"""\n\n<!-- Association note -->"""
(x,y) = (cx[u"note"],cy[u"note"])
(ex,ey) = (cx[u"UEs"],cy[u"UEs"])
lines += u"""\n<line x1="%(x0)s" y1="%(y0)s" x2="%(x1)s" y2="%(y1)s" stroke="%(strokeColor)s" stroke-width="2"/>""" % {'x0': ex, 'y0': ey, 'x1': x, 'y1': y, 'strokeColor': colors['legStrokeColor']}
(tx,ty) = cardPos(ex,11.9+ey,37,64,x,11.9+y,k[u"note,UEs"])
lines += u"""\n<text x="%(tx)s" y="%(ty)s" fill="%(textColor)s" font-family="Verdana" font-size="12">0,N</text>""" % {'tx': tx, 'ty': ty, 'textColor': colors['cardTextColor']}
(ex,ey) = (cx[u"Types_Notes"],cy[u"Types_Notes"])
lines += u"""\n<line x1="%(x0)s" y1="%(y0)s" x2="%(x1)s" y2="%(y1)s" stroke="%(strokeColor)s" stroke-width="2"/>""" % {'x0': ex, 'y0': ey, 'x1': x, 'y1': y, 'strokeColor': colors['legStrokeColor']}
(tx,ty) = cardPos(ex,11.9+ey,44,40,x,11.9+y,k[u"note,Types_Notes"])
lines += u"""\n<text x="%(tx)s" y="%(ty)s" fill="%(textColor)s" font-family="Verdana" font-size="12">0,N</text>""" % {'tx': tx, 'ty': ty, 'textColor': colors['cardTextColor']}
(ex,ey) = (cx[u"Etudiants"],cy[u"Etudiants"])
lines += u"""\n<line x1="%(x0)s" y1="%(y0)s" x2="%(x1)s" y2="%(y1)s" stroke="%(strokeColor)s" stroke-width="2"/>""" % {'x0': ex, 'y0': ey, 'x1': x, 'y1': y, 'strokeColor': colors['legStrokeColor']}
(tx,ty) = cardPos(ex,11.9+ey,33,24,x,11.9+y,k[u"note,Etudiants"])
lines += u"""\n<text x="%(tx)s" y="%(ty)s" fill="%(textColor)s" font-family="Verdana" font-size="12">0,N</text>""" % {'tx': tx, 'ty': ty, 'textColor': colors['cardTextColor']}
lines += u"""\n<g id="association-note">""" % {}
path = upperRoundRect(-33+x,-48+y,66,24,14)
lines += u"""\n	<path d="%(path)s" fill="%(color)s" stroke="%(strokeColor)s" stroke-width="0"/>""" % {'path': path, 'color': colors['associationCartoucheColor'], 'strokeColor': colors['associationCartoucheColor']}
path = lowerRoundRect(-33+x,-24+y,66,72,14)
lines += u"""\n	<path d="%(path)s" fill="%(color)s" stroke="%(strokeColor)s" stroke-width="0"/>""" % {'path': path, 'color': colors['associationColor'], 'strokeColor': colors['associationColor']}
lines += u"""\n	<rect x="%(x)s" y="%(y)s" width="66" height="96" fill="%(color)s" rx="14" stroke="%(strokeColor)s" stroke-width="2"/>""" % {'x': -33+x, 'y': -48+y, 'color': colors['transparentColor'], 'strokeColor': colors['associationStrokeColor']}
lines += u"""\n	<line x1="%(x0)s" y1="%(y0)s" x2="%(x1)s" y2="%(y1)s" stroke="%(strokeColor)s" stroke-width="1"/>""" % {'x0': -33+x, 'y0': -24+y, 'x1': 33+x, 'y1': -24+y, 'strokeColor': colors['associationStrokeColor']}
lines += u"""\n	<text x="%(x)s" y="%(y)s" fill="%(textColor)s" font-family="Verdana" font-size="12">note</text>""" % {'x': -14+x, 'y': -31.1+y, 'textColor': colors['associationCartoucheTextColor']}
lines += u"""\n	<text x="%(x)s" y="%(y)s" fill="%(textColor)s" font-family="Verdana" font-size="12">absence</text>""" % {'x': -26+x, 'y': -7.1+y, 'textColor': colors['associationAttributeTextColor']}
lines += u"""\n	<text x="%(x)s" y="%(y)s" fill="%(textColor)s" font-family="Verdana" font-size="12">typeAbs</text>""" % {'x': -26+x, 'y': 8.9+y, 'textColor': colors['associationAttributeTextColor']}
lines += u"""\n	<text x="%(x)s" y="%(y)s" fill="%(textColor)s" font-family="Verdana" font-size="12">session1</text>""" % {'x': -26+x, 'y': 24.9+y, 'textColor': colors['associationAttributeTextColor']}
lines += u"""\n	<text x="%(x)s" y="%(y)s" fill="%(textColor)s" font-family="Verdana" font-size="12">note</text>""" % {'x': -26+x, 'y': 40.9+y, 'textColor': colors['associationAttributeTextColor']}
lines += u"""\n</g>""" % {}

lines += u"""\n\n<!-- Association responsables -->"""
(x,y) = (cx[u"responsables"],cy[u"responsables"])
(ex,ey) = (cx[u"UEs"],cy[u"UEs"])
lines += u"""\n<line x1="%(x0)s" y1="%(y0)s" x2="%(x1)s" y2="%(y1)s" stroke="%(strokeColor)s" stroke-width="2"/>""" % {'x0': ex, 'y0': ey, 'x1': x, 'y1': y, 'strokeColor': colors['legStrokeColor']}
(tx,ty) = cardPos(ex,11.9+ey,37,64,x,11.9+y,k[u"responsables,UEs"])
lines += u"""\n<text x="%(tx)s" y="%(ty)s" fill="%(textColor)s" font-family="Verdana" font-size="12">0,N</text>""" % {'tx': tx, 'ty': ty, 'textColor': colors['cardTextColor']}
(ex,ey) = (cx[u"Enseignants"],cy[u"Enseignants"])
lines += u"""\n<line x1="%(x0)s" y1="%(y0)s" x2="%(x1)s" y2="%(y1)s" stroke="%(strokeColor)s" stroke-width="2"/>""" % {'x0': ex, 'y0': ey, 'x1': x, 'y1': y, 'strokeColor': colors['legStrokeColor']}
(tx,ty) = cardPos(ex,11.9+ey,42,24,x,11.9+y,k[u"responsables,Enseignants"])
lines += u"""\n<text x="%(tx)s" y="%(ty)s" fill="%(textColor)s" font-family="Verdana" font-size="12">0,N</text>""" % {'tx': tx, 'ty': ty, 'textColor': colors['cardTextColor']}
lines += u"""\n<g id="association-responsables">""" % {}
path = upperRoundRect(-47+x,-24+y,94,24,14)
lines += u"""\n	<path d="%(path)s" fill="%(color)s" stroke="%(strokeColor)s" stroke-width="0"/>""" % {'path': path, 'color': colors['associationCartoucheColor'], 'strokeColor': colors['associationCartoucheColor']}
path = lowerRoundRect(-47+x,0+y,94,24,14)
lines += u"""\n	<path d="%(path)s" fill="%(color)s" stroke="%(strokeColor)s" stroke-width="0"/>""" % {'path': path, 'color': colors['associationColor'], 'strokeColor': colors['associationColor']}
lines += u"""\n	<rect x="%(x)s" y="%(y)s" width="94" height="48" fill="%(color)s" rx="14" stroke="%(strokeColor)s" stroke-width="2"/>""" % {'x': -47+x, 'y': -24+y, 'color': colors['transparentColor'], 'strokeColor': colors['associationStrokeColor']}
lines += u"""\n	<line x1="%(x0)s" y1="%(y0)s" x2="%(x1)s" y2="%(y1)s" stroke="%(strokeColor)s" stroke-width="1"/>""" % {'x0': -47+x, 'y0': 0+y, 'x1': 47+x, 'y1': 0+y, 'strokeColor': colors['associationStrokeColor']}
lines += u"""\n	<text x="%(x)s" y="%(y)s" fill="%(textColor)s" font-family="Verdana" font-size="12">responsables</text>""" % {'x': -40+x, 'y': -7.1+y, 'textColor': colors['associationCartoucheTextColor']}
lines += u"""\n</g>""" % {}

lines += u"""\n\n<!-- Association reliées -->"""
(x,y) = (cx[u"reliées"],cy[u"reliées"])
(ex,ey) = (cx[u"Etudiants"],cy[u"Etudiants"])
lines += u"""\n<line x1="%(x0)s" y1="%(y0)s" x2="%(x1)s" y2="%(y1)s" stroke="%(strokeColor)s" stroke-width="2"/>""" % {'x0': ex, 'y0': ey, 'x1': x, 'y1': y, 'strokeColor': colors['legStrokeColor']}
(tx,ty) = cardPos(ex,11.9+ey,33,24,x,11.9+y,k[u"reliées,Etudiants"])
lines += u"""\n<text x="%(tx)s" y="%(ty)s" fill="%(textColor)s" font-family="Verdana" font-size="12">0,N</text>""" % {'tx': tx, 'ty': ty, 'textColor': colors['cardTextColor']}
(ex,ey) = (cx[u"Semestres"],cy[u"Semestres"])
lines += u"""\n<line x1="%(x0)s" y1="%(y0)s" x2="%(x1)s" y2="%(y1)s" stroke="%(strokeColor)s" stroke-width="2"/>""" % {'x0': ex, 'y0': ey, 'x1': x, 'y1': y, 'strokeColor': colors['legStrokeColor']}
(tx,ty) = cardPos(ex,11.9+ey,37,24,x,11.9+y,k[u"reliées,Semestres"])
lines += u"""\n<text x="%(tx)s" y="%(ty)s" fill="%(textColor)s" font-family="Verdana" font-size="12">0,N</text>""" % {'tx': tx, 'ty': ty, 'textColor': colors['cardTextColor']}
lines += u"""\n<g id="association-reliées">""" % {}
path = upperRoundRect(-47+x,-40+y,94,24,14)
lines += u"""\n	<path d="%(path)s" fill="%(color)s" stroke="%(strokeColor)s" stroke-width="0"/>""" % {'path': path, 'color': colors['associationCartoucheColor'], 'strokeColor': colors['associationCartoucheColor']}
path = lowerRoundRect(-47+x,-16+y,94,56,14)
lines += u"""\n	<path d="%(path)s" fill="%(color)s" stroke="%(strokeColor)s" stroke-width="0"/>""" % {'path': path, 'color': colors['associationColor'], 'strokeColor': colors['associationColor']}
lines += u"""\n	<rect x="%(x)s" y="%(y)s" width="94" height="80" fill="%(color)s" rx="14" stroke="%(strokeColor)s" stroke-width="2"/>""" % {'x': -47+x, 'y': -40+y, 'color': colors['transparentColor'], 'strokeColor': colors['associationStrokeColor']}
lines += u"""\n	<line x1="%(x0)s" y1="%(y0)s" x2="%(x1)s" y2="%(y1)s" stroke="%(strokeColor)s" stroke-width="1"/>""" % {'x0': -47+x, 'y0': -16+y, 'x1': 47+x, 'y1': -16+y, 'strokeColor': colors['associationStrokeColor']}
lines += u"""\n	<text x="%(x)s" y="%(y)s" fill="%(textColor)s" font-family="Verdana" font-size="12">reliées</text>""" % {'x': -20+x, 'y': -23.1+y, 'textColor': colors['associationCartoucheTextColor']}
lines += u"""\n	<text x="%(x)s" y="%(y)s" fill="%(textColor)s" font-family="Verdana" font-size="12">moySem</text>""" % {'x': -40+x, 'y': 0.9+y, 'textColor': colors['associationAttributeTextColor']}
lines += u"""\n	<text x="%(x)s" y="%(y)s" fill="%(textColor)s" font-family="Verdana" font-size="12">valide</text>""" % {'x': -40+x, 'y': 16.9+y, 'textColor': colors['associationAttributeTextColor']}
lines += u"""\n	<text x="%(x)s" y="%(y)s" fill="%(textColor)s" font-family="Verdana" font-size="12">compensable</text>""" % {'x': -40+x, 'y': 32.9+y, 'textColor': colors['associationAttributeTextColor']}
lines += u"""\n</g>""" % {}

lines += u"""\n\n<!-- Association X -->"""
(x,y) = (cx[u"X"],cy[u"X"])
(ex,ey) = (cx[u"Enseignants"],cy[u"Enseignants"])
lines += u"""\n<line x1="%(x0)s" y1="%(y0)s" x2="%(x1)s" y2="%(y1)s" stroke="%(strokeColor)s" stroke-width="2"/>""" % {'x0': ex, 'y0': ey, 'x1': x, 'y1': y, 'strokeColor': colors['legStrokeColor']}
(tx,ty) = cardPos(ex,11.9+ey,42,24,x,11.9+y,k[u"X,Enseignants"])
lines += u"""\n<text x="%(tx)s" y="%(ty)s" fill="%(textColor)s" font-family="Verdana" font-size="12"></text>""" % {'tx': tx, 'ty': ty, 'textColor': colors['cardTextColor']}
path = lineArrow(ex,ey,x,y,t[u"X,Enseignants"])
lines += u"""\n<path d="%(path)s" fill="%(strokeColor)s" stroke-width="0"/>""" % {'path': path, 'strokeColor': colors['legStrokeColor']}
(ex,ey) = (cx[u"Etudiants"],cy[u"Etudiants"])
lines += u"""\n<line x1="%(x0)s" y1="%(y0)s" x2="%(x1)s" y2="%(y1)s" stroke="%(strokeColor)s" stroke-width="2"/>""" % {'x0': ex, 'y0': ey, 'x1': x, 'y1': y, 'strokeColor': colors['legStrokeColor']}
(tx,ty) = cardPos(ex,11.9+ey,33,24,x,11.9+y,k[u"X,Etudiants"])
lines += u"""\n<text x="%(tx)s" y="%(ty)s" fill="%(textColor)s" font-family="Verdana" font-size="12"></text>""" % {'tx': tx, 'ty': ty, 'textColor': colors['cardTextColor']}
path = lineArrow(ex,ey,x,y,t[u"X,Etudiants"])
lines += u"""\n<path d="%(path)s" fill="%(strokeColor)s" stroke-width="0"/>""" % {'path': path, 'strokeColor': colors['legStrokeColor']}
(ex,ey) = (cx[u"Users"],cy[u"Users"])
lines += u"""\n<line x1="%(x0)s" y1="%(y0)s" x2="%(x1)s" y2="%(y1)s" stroke="%(strokeColor)s" stroke-width="2"/>""" % {'x0': ex, 'y0': ey, 'x1': x, 'y1': y, 'strokeColor': colors['legStrokeColor']}
(tx,ty) = cardPos(ex,11.9+ey,35,64,x,11.9+y,k[u"X,Users"])
lines += u"""\n<text x="%(tx)s" y="%(ty)s" fill="%(textColor)s" font-family="Verdana" font-size="12"></text>""" % {'tx': tx, 'ty': ty, 'textColor': colors['cardTextColor']}
path = lineArrow(x,y,ex,ey,t[u"X,Users"])
lines += u"""\n<path d="%(path)s" fill="%(strokeColor)s" stroke-width="0"/>""" % {'path': path, 'strokeColor': colors['legStrokeColor']}
lines += u"""\n<g id="association-X">""" % {}
lines += u"""\n	<circle cx="%(cx)s" cy="%(cy)s" r="14.0" stroke="%(strokeColor)s" stroke-width="2" fill="%(color)s"/>""" % {'cx': x, 'cy': y, 'strokeColor': colors['associationStrokeColor'], 'color': colors['associationCartoucheColor']}
lines += u"""\n	<text x="%(x)s" y="%(y)s" fill="%(textColor)s" font-family="Verdana" font-size="12">X</text>""" % {'x': -7+x, 'y': 5.0+y, 'textColor': colors['associationCartoucheTextColor']}
lines += u"""\n</g>""" % {}

lines += u"""\n\n<!-- Entity Semestres -->"""
(x,y) = (cx[u"Semestres"],cy[u"Semestres"])
lines += u"""\n<g id="entity-Semestres">""" % {}
lines += u"""\n	<g id="frame-Semestres">""" % {}
lines += u"""\n		<rect x="%(x)s" y="%(y)s" width="74" height="24" fill="%(color)s" stroke="%(strokeColor)s" stroke-width="0"/>""" % {'x': -37+x, 'y': -24+y, 'color': colors['entityCartoucheColor'], 'strokeColor': colors['entityCartoucheColor']}
lines += u"""\n		<rect x="%(x)s" y="%(y)s" width="74" height="24" fill="%(color)s" stroke="%(strokeColor)s" stroke-width="0"/>""" % {'x': -37+x, 'y': 0+y, 'color': colors['entityColor'], 'strokeColor': colors['entityColor']}
lines += u"""\n		<rect x="%(x)s" y="%(y)s" width="74" height="48" fill="%(color)s" stroke="%(strokeColor)s" stroke-width="2"/>""" % {'x': -37+x, 'y': -24+y, 'color': colors['transparentColor'], 'strokeColor': colors['entityStrokeColor']}
lines += u"""\n		<line x1="%(x0)s" y1="%(y0)s" x2="%(x1)s" y2="%(y1)s" stroke="%(strokeColor)s" stroke-width="1"/>""" % {'x0': -37+x, 'y0': 0+y, 'x1': 37+x, 'y1': 0+y, 'strokeColor': colors['entityStrokeColor']}
lines += u"""\n	</g>""" % {}
lines += u"""\n	<text x="%(x)s" y="%(y)s" fill="%(textColor)s" font-family="Verdana" font-size="12">Semestres</text>""" % {'x': -32+x, 'y': -7.1+y, 'textColor': colors['entityCartoucheTextColor']}
lines += u"""\n	<text x="%(x)s" y="%(y)s" fill="%(textColor)s" font-family="Verdana" font-size="12">numSem</text>""" % {'x': -32+x, 'y': 16.9+y, 'textColor': colors['entityAttributeTextColor']}
lines += u"""\n	<line x1="%(x0)s" y1="%(y)s" x2="%(x1)s" y2="%(y)s" style="fill:none;stroke:%(strokeColor)s;stroke-width:1;stroke-dasharray:4;"/>""" % {'x0': -32+x, 'y': 19.0+y, 'x1': 22+x, 'y': 19.0+y, 'strokeColor': colors['entityAttributeTextColor']}
lines += u"""\n</g>""" % {}

lines += u"""\n\n<!-- Entity Users -->"""
(x,y) = (cx[u"Users"],cy[u"Users"])
lines += u"""\n<g id="entity-Users">""" % {}
lines += u"""\n	<g id="frame-Users">""" % {}
lines += u"""\n		<rect x="%(x)s" y="%(y)s" width="70" height="24" fill="%(color)s" stroke="%(strokeColor)s" stroke-width="0"/>""" % {'x': -35+x, 'y': -64+y, 'color': colors['entityCartoucheColor'], 'strokeColor': colors['entityCartoucheColor']}
lines += u"""\n		<rect x="%(x)s" y="%(y)s" width="70" height="104" fill="%(color)s" stroke="%(strokeColor)s" stroke-width="0"/>""" % {'x': -35+x, 'y': -40+y, 'color': colors['entityColor'], 'strokeColor': colors['entityColor']}
lines += u"""\n		<rect x="%(x)s" y="%(y)s" width="70" height="128" fill="%(color)s" stroke="%(strokeColor)s" stroke-width="2"/>""" % {'x': -35+x, 'y': -64+y, 'color': colors['transparentColor'], 'strokeColor': colors['entityStrokeColor']}
lines += u"""\n		<line x1="%(x0)s" y1="%(y0)s" x2="%(x1)s" y2="%(y1)s" stroke="%(strokeColor)s" stroke-width="1"/>""" % {'x0': -35+x, 'y0': -40+y, 'x1': 35+x, 'y1': -40+y, 'strokeColor': colors['entityStrokeColor']}
lines += u"""\n	</g>""" % {}
lines += u"""\n	<text x="%(x)s" y="%(y)s" fill="%(textColor)s" font-family="Verdana" font-size="12">Users</text>""" % {'x': -17+x, 'y': -47.1+y, 'textColor': colors['entityCartoucheTextColor']}
lines += u"""\n	<text x="%(x)s" y="%(y)s" fill="%(textColor)s" font-family="Verdana" font-size="12">id</text>""" % {'x': -30+x, 'y': -23.1+y, 'textColor': colors['entityAttributeTextColor']}
lines += u"""\n	<line x1="%(x0)s" y1="%(y0)s" x2="%(x1)s" y2="%(y1)s" stroke="%(strokeColor)s" stroke-width="1"/>""" % {'x0': -30+x, 'y0': -21.0+y, 'x1': -19+x, 'y1': -21.0+y, 'strokeColor': colors['entityAttributeTextColor']}
lines += u"""\n	<text x="%(x)s" y="%(y)s" fill="%(textColor)s" font-family="Verdana" font-size="12">firstname</text>""" % {'x': -30+x, 'y': -7.1+y, 'textColor': colors['entityAttributeTextColor']}
lines += u"""\n	<text x="%(x)s" y="%(y)s" fill="%(textColor)s" font-family="Verdana" font-size="12">lastname</text>""" % {'x': -30+x, 'y': 8.9+y, 'textColor': colors['entityAttributeTextColor']}
lines += u"""\n	<text x="%(x)s" y="%(y)s" fill="%(textColor)s" font-family="Verdana" font-size="12">username</text>""" % {'x': -30+x, 'y': 24.9+y, 'textColor': colors['entityAttributeTextColor']}
lines += u"""\n	<text x="%(x)s" y="%(y)s" fill="%(textColor)s" font-family="Verdana" font-size="12">password</text>""" % {'x': -30+x, 'y': 40.9+y, 'textColor': colors['entityAttributeTextColor']}
lines += u"""\n	<text x="%(x)s" y="%(y)s" fill="%(textColor)s" font-family="Verdana" font-size="12">role</text>""" % {'x': -30+x, 'y': 56.9+y, 'textColor': colors['entityAttributeTextColor']}
lines += u"""\n</g>""" % {}

lines += u"""\n\n<!-- Entity Annees -->"""
(x,y) = (cx[u"Annees"],cy[u"Annees"])
lines += u"""\n<g id="entity-Annees">""" % {}
lines += u"""\n	<g id="frame-Annees">""" % {}
lines += u"""\n		<rect x="%(x)s" y="%(y)s" width="76" height="24" fill="%(color)s" stroke="%(strokeColor)s" stroke-width="0"/>""" % {'x': -38+x, 'y': -40+y, 'color': colors['entityCartoucheColor'], 'strokeColor': colors['entityCartoucheColor']}
lines += u"""\n		<rect x="%(x)s" y="%(y)s" width="76" height="56" fill="%(color)s" stroke="%(strokeColor)s" stroke-width="0"/>""" % {'x': -38+x, 'y': -16+y, 'color': colors['entityColor'], 'strokeColor': colors['entityColor']}
lines += u"""\n		<rect x="%(x)s" y="%(y)s" width="76" height="80" fill="%(color)s" stroke="%(strokeColor)s" stroke-width="2"/>""" % {'x': -38+x, 'y': -40+y, 'color': colors['transparentColor'], 'strokeColor': colors['entityStrokeColor']}
lines += u"""\n		<line x1="%(x0)s" y1="%(y0)s" x2="%(x1)s" y2="%(y1)s" stroke="%(strokeColor)s" stroke-width="1"/>""" % {'x0': -38+x, 'y0': -16+y, 'x1': 38+x, 'y1': -16+y, 'strokeColor': colors['entityStrokeColor']}
lines += u"""\n	</g>""" % {}
lines += u"""\n	<text x="%(x)s" y="%(y)s" fill="%(textColor)s" font-family="Verdana" font-size="12">Annees</text>""" % {'x': -22+x, 'y': -23.1+y, 'textColor': colors['entityCartoucheTextColor']}
lines += u"""\n	<text x="%(x)s" y="%(y)s" fill="%(textColor)s" font-family="Verdana" font-size="12">id</text>""" % {'x': -33+x, 'y': 0.9+y, 'textColor': colors['entityAttributeTextColor']}
lines += u"""\n	<line x1="%(x0)s" y1="%(y0)s" x2="%(x1)s" y2="%(y1)s" stroke="%(strokeColor)s" stroke-width="1"/>""" % {'x0': -33+x, 'y0': 3.0+y, 'x1': -22+x, 'y1': 3.0+y, 'strokeColor': colors['entityAttributeTextColor']}
lines += u"""\n	<text x="%(x)s" y="%(y)s" fill="%(textColor)s" font-family="Verdana" font-size="12">diplome</text>""" % {'x': -33+x, 'y': 16.9+y, 'textColor': colors['entityAttributeTextColor']}
lines += u"""\n	<text x="%(x)s" y="%(y)s" fill="%(textColor)s" font-family="Verdana" font-size="12">description</text>""" % {'x': -33+x, 'y': 32.9+y, 'textColor': colors['entityAttributeTextColor']}
lines += u"""\n</g>""" % {}

lines += u"""\n\n<!-- Entity Etudiants -->"""
(x,y) = (cx[u"Etudiants"],cy[u"Etudiants"])
lines += u"""\n<g id="entity-Etudiants">""" % {}
lines += u"""\n	<g id="frame-Etudiants">""" % {}
lines += u"""\n		<rect x="%(x)s" y="%(y)s" width="66" height="24" fill="%(color)s" stroke="%(strokeColor)s" stroke-width="0"/>""" % {'x': -33+x, 'y': -24+y, 'color': colors['entityCartoucheColor'], 'strokeColor': colors['entityCartoucheColor']}
lines += u"""\n		<rect x="%(x)s" y="%(y)s" width="66" height="24" fill="%(color)s" stroke="%(strokeColor)s" stroke-width="0"/>""" % {'x': -33+x, 'y': 0+y, 'color': colors['entityColor'], 'strokeColor': colors['entityColor']}
lines += u"""\n		<rect x="%(x)s" y="%(y)s" width="66" height="48" fill="%(color)s" stroke="%(strokeColor)s" stroke-width="2"/>""" % {'x': -33+x, 'y': -24+y, 'color': colors['transparentColor'], 'strokeColor': colors['entityStrokeColor']}
lines += u"""\n		<line x1="%(x0)s" y1="%(y0)s" x2="%(x1)s" y2="%(y1)s" stroke="%(strokeColor)s" stroke-width="1"/>""" % {'x0': -33+x, 'y0': 0+y, 'x1': 33+x, 'y1': 0+y, 'strokeColor': colors['entityStrokeColor']}
lines += u"""\n	</g>""" % {}
lines += u"""\n	<text x="%(x)s" y="%(y)s" fill="%(textColor)s" font-family="Verdana" font-size="12">Etudiants</text>""" % {'x': -28+x, 'y': -7.1+y, 'textColor': colors['entityCartoucheTextColor']}
lines += u"""\n	<text x="%(x)s" y="%(y)s" fill="%(textColor)s" font-family="Verdana" font-size="12">numero</text>""" % {'x': -28+x, 'y': 16.9+y, 'textColor': colors['entityAttributeTextColor']}
lines += u"""\n	<line x1="%(x0)s" y1="%(y0)s" x2="%(x1)s" y2="%(y1)s" stroke="%(strokeColor)s" stroke-width="1"/>""" % {'x0': -28+x, 'y0': 19.0+y, 'x1': 18+x, 'y1': 19.0+y, 'strokeColor': colors['entityAttributeTextColor']}
lines += u"""\n</g>""" % {}

lines += u"""\n\n<!-- Entity Types_Notes -->"""
(x,y) = (cx[u"Types_Notes"],cy[u"Types_Notes"])
lines += u"""\n<g id="entity-Types_Notes">""" % {}
lines += u"""\n	<g id="frame-Types_Notes">""" % {}
lines += u"""\n		<rect x="%(x)s" y="%(y)s" width="88" height="24" fill="%(color)s" stroke="%(strokeColor)s" stroke-width="0"/>""" % {'x': -44+x, 'y': -40+y, 'color': colors['entityCartoucheColor'], 'strokeColor': colors['entityCartoucheColor']}
lines += u"""\n		<rect x="%(x)s" y="%(y)s" width="88" height="56" fill="%(color)s" stroke="%(strokeColor)s" stroke-width="0"/>""" % {'x': -44+x, 'y': -16+y, 'color': colors['entityColor'], 'strokeColor': colors['entityColor']}
lines += u"""\n		<rect x="%(x)s" y="%(y)s" width="88" height="80" fill="%(color)s" stroke="%(strokeColor)s" stroke-width="2"/>""" % {'x': -44+x, 'y': -40+y, 'color': colors['transparentColor'], 'strokeColor': colors['entityStrokeColor']}
lines += u"""\n		<line x1="%(x0)s" y1="%(y0)s" x2="%(x1)s" y2="%(y1)s" stroke="%(strokeColor)s" stroke-width="1"/>""" % {'x0': -44+x, 'y0': -16+y, 'x1': 44+x, 'y1': -16+y, 'strokeColor': colors['entityStrokeColor']}
lines += u"""\n	</g>""" % {}
lines += u"""\n	<text x="%(x)s" y="%(y)s" fill="%(textColor)s" font-family="Verdana" font-size="12">Types_Notes</text>""" % {'x': -39+x, 'y': -23.1+y, 'textColor': colors['entityCartoucheTextColor']}
lines += u"""\n	<text x="%(x)s" y="%(y)s" fill="%(textColor)s" font-family="Verdana" font-size="12">id</text>""" % {'x': -39+x, 'y': 0.9+y, 'textColor': colors['entityAttributeTextColor']}
lines += u"""\n	<line x1="%(x0)s" y1="%(y0)s" x2="%(x1)s" y2="%(y1)s" stroke="%(strokeColor)s" stroke-width="1"/>""" % {'x0': -39+x, 'y0': 3.0+y, 'x1': -28+x, 'y1': 3.0+y, 'strokeColor': colors['entityAttributeTextColor']}
lines += u"""\n	<text x="%(x)s" y="%(y)s" fill="%(textColor)s" font-family="Verdana" font-size="12">name</text>""" % {'x': -39+x, 'y': 16.9+y, 'textColor': colors['entityAttributeTextColor']}
lines += u"""\n	<text x="%(x)s" y="%(y)s" fill="%(textColor)s" font-family="Verdana" font-size="12">sigle</text>""" % {'x': -39+x, 'y': 32.9+y, 'textColor': colors['entityAttributeTextColor']}
lines += u"""\n</g>""" % {}

lines += u"""\n\n<!-- Entity Enseignants -->"""
(x,y) = (cx[u"Enseignants"],cy[u"Enseignants"])
lines += u"""\n<g id="entity-Enseignants">""" % {}
lines += u"""\n	<g id="frame-Enseignants">""" % {}
lines += u"""\n		<rect x="%(x)s" y="%(y)s" width="84" height="24" fill="%(color)s" stroke="%(strokeColor)s" stroke-width="0"/>""" % {'x': -42+x, 'y': -24+y, 'color': colors['entityCartoucheColor'], 'strokeColor': colors['entityCartoucheColor']}
lines += u"""\n		<rect x="%(x)s" y="%(y)s" width="84" height="24" fill="%(color)s" stroke="%(strokeColor)s" stroke-width="0"/>""" % {'x': -42+x, 'y': 0+y, 'color': colors['entityColor'], 'strokeColor': colors['entityColor']}
lines += u"""\n		<rect x="%(x)s" y="%(y)s" width="84" height="48" fill="%(color)s" stroke="%(strokeColor)s" stroke-width="2"/>""" % {'x': -42+x, 'y': -24+y, 'color': colors['transparentColor'], 'strokeColor': colors['entityStrokeColor']}
lines += u"""\n		<line x1="%(x0)s" y1="%(y0)s" x2="%(x1)s" y2="%(y1)s" stroke="%(strokeColor)s" stroke-width="1"/>""" % {'x0': -42+x, 'y0': 0+y, 'x1': 42+x, 'y1': 0+y, 'strokeColor': colors['entityStrokeColor']}
lines += u"""\n	</g>""" % {}
lines += u"""\n	<text x="%(x)s" y="%(y)s" fill="%(textColor)s" font-family="Verdana" font-size="12">Enseignants</text>""" % {'x': -37+x, 'y': -7.1+y, 'textColor': colors['entityCartoucheTextColor']}
lines += u"""\n</g>""" % {}

lines += u"""\n\n<!-- Entity UEs -->"""
(x,y) = (cx[u"UEs"],cy[u"UEs"])
lines += u"""\n<g id="entity-UEs">""" % {}
lines += u"""\n	<g id="frame-UEs">""" % {}
lines += u"""\n		<rect x="%(x)s" y="%(y)s" width="74" height="24" fill="%(color)s" stroke="%(strokeColor)s" stroke-width="0"/>""" % {'x': -37+x, 'y': -64+y, 'color': colors['entityCartoucheColor'], 'strokeColor': colors['entityCartoucheColor']}
lines += u"""\n		<rect x="%(x)s" y="%(y)s" width="74" height="104" fill="%(color)s" stroke="%(strokeColor)s" stroke-width="0"/>""" % {'x': -37+x, 'y': -40+y, 'color': colors['entityColor'], 'strokeColor': colors['entityColor']}
lines += u"""\n		<rect x="%(x)s" y="%(y)s" width="74" height="128" fill="%(color)s" stroke="%(strokeColor)s" stroke-width="2"/>""" % {'x': -37+x, 'y': -64+y, 'color': colors['transparentColor'], 'strokeColor': colors['entityStrokeColor']}
lines += u"""\n		<line x1="%(x0)s" y1="%(y0)s" x2="%(x1)s" y2="%(y1)s" stroke="%(strokeColor)s" stroke-width="1"/>""" % {'x0': -37+x, 'y0': -40+y, 'x1': 37+x, 'y1': -40+y, 'strokeColor': colors['entityStrokeColor']}
lines += u"""\n	</g>""" % {}
lines += u"""\n	<text x="%(x)s" y="%(y)s" fill="%(textColor)s" font-family="Verdana" font-size="12">UEs</text>""" % {'x': -12+x, 'y': -47.1+y, 'textColor': colors['entityCartoucheTextColor']}
lines += u"""\n	<text x="%(x)s" y="%(y)s" fill="%(textColor)s" font-family="Verdana" font-size="12">id</text>""" % {'x': -32+x, 'y': -23.1+y, 'textColor': colors['entityAttributeTextColor']}
lines += u"""\n	<line x1="%(x0)s" y1="%(y0)s" x2="%(x1)s" y2="%(y1)s" stroke="%(strokeColor)s" stroke-width="1"/>""" % {'x0': -32+x, 'y0': -21.0+y, 'x1': -21+x, 'y1': -21.0+y, 'strokeColor': colors['entityAttributeTextColor']}
lines += u"""\n	<text x="%(x)s" y="%(y)s" fill="%(textColor)s" font-family="Verdana" font-size="12">name</text>""" % {'x': -32+x, 'y': -7.1+y, 'textColor': colors['entityAttributeTextColor']}
lines += u"""\n	<text x="%(x)s" y="%(y)s" fill="%(textColor)s" font-family="Verdana" font-size="12">sup1</text>""" % {'x': -32+x, 'y': 8.9+y, 'textColor': colors['entityAttributeTextColor']}
lines += u"""\n	<text x="%(x)s" y="%(y)s" fill="%(textColor)s" font-family="Verdana" font-size="12">sup2</text>""" % {'x': -32+x, 'y': 24.9+y, 'textColor': colors['entityAttributeTextColor']}
lines += u"""\n	<text x="%(x)s" y="%(y)s" fill="%(textColor)s" font-family="Verdana" font-size="12">obligatoire</text>""" % {'x': -32+x, 'y': 40.9+y, 'textColor': colors['entityAttributeTextColor']}
lines += u"""\n	<text x="%(x)s" y="%(y)s" fill="%(textColor)s" font-family="Verdana" font-size="12">coefUE</text>""" % {'x': -32+x, 'y': 56.9+y, 'textColor': colors['entityAttributeTextColor']}
lines += u"""\n</g>""" % {}
lines += u'\n</svg>'

import codecs
codecs.open("MCD_ProjetStage2015.svg","w","utf8").write(lines)
safePrint(u'Fichier de sortie "MCD_ProjetStage2015.svg" généré avec succès.')